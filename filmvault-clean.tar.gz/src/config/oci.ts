import dotenv from 'dotenv';

dotenv.config();

const parUrl = process.env.OCI_PAR_URL || '';

export const ociConfig = {
  objectStorage: {
    parUrl,
    
    getProfilePictureUrl: (objectName: string): string => {
      return `${parUrl}${objectName}`;
    }
  },
  
  isConfigValid: (): boolean => {
    return false;
  },
  
  isObjectStorageConfigValid: (): boolean => {
    if (!parUrl) {
      console.error('OCI_PAR_URL environment variable is not set');
      return false;
    }
    return true;
  },
  
  createObjectStorageClient: () => {
    console.log('Using PAR for object storage access');
    return null;
  }
};

console.log('Using PAR URL for profile pictures: ' + (parUrl ? 'Configured' : 'Not configured'));

export default ociConfig;